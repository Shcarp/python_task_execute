
def run(params):
    print(params)
