from setuptools import find_namespace_packages, setup
 
setup(
   name='addNum',
   version='0.0.1',
   packages=['addNum'],
)