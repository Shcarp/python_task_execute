__all__ = ["add"]

from addNum.add import add;

def run(param):
    return add(param["a"], param["b"])
